function initMap() {
                var map = new google.maps.Map(document.getElementById("map"), {
                    center: {lat: parseFloat(-24.90387784417046), lng: parseFloat(133.9211859007968) },
                    zoom: 4,
                });
            }